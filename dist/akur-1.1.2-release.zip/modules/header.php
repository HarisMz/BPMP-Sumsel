<header class="header container">
    <nav class="wrapper">
        <a href="/" class="logo"></a>
        <nav class="mobile-menu bg-contain"></nav>
        <ul class="menu">
            <li class="item dropdown">
                Profil
                <div class="dropdown-wrapper">
                    <ul class="list surface">
                        <li class="list-item dropdown">
                            Profil Organisasi
                            <div class="dropdown-wrapper">
                                <ul class="list surface">
                                    <li class="list-item"><a href="/profil/profil-organisasi/visi-dan-misi">Visi dan Misi</a></li>
                                    <li class="list-item"><a href="/profil/profil-organisasi/tugas-dan-fungsi">Tugas dan Fungsi</a></li>
                                    <li class="list-item"><a href="/profil/profil-organisasi/struktur-organisasi">Struktur Organisasi</a></li>
                                    <li class="list-item"><a href="/profil/profil-organisasi/pimpinan-unit-satker-dari-masa-ke-masa">Pimpinan Unit/Satker dari Masa ke Masa</a></li>
                                </ul>
                            </div>
                        </li>
                        <li class="list-item dropdown">
                            Kinerja Organisasi
                            <div class="dropdown-wrapper">
                                <ul class="list surface">
                                    <li class="list-item"><a href="/profil/kinerja-organisasi/rencana-kerja">Rencana Kerja</a></li>
                                    <li class="list-item"><a href="/profil/kinerja-organisasi/perjanjian-kerja">Perjanjian Kerja</a></li>
                                    <li class="list-item"><a href="/profil/kinerja-organisasi/laporan">Laporan</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="item dropdown">
                Berita
                <div class="dropdown-wrapper">
                    <ul class="list surface">
                        <li class="list-item"><a href="/berita/rilis">Rilis</a></li>
                        <li class="list-item"><a href="/berita/artikel">Artikel</a></li>
                        <li class="list-item"><a href="/berita/agenda">Agenda</a></li>
                        <li class="list-item"><a href="/berita/pengumuman">Pengumuman</a></li>
                    </ul>
                </div>
            </li>
            <li class="item dropdown">
                Layanan
                <div class="dropdown-wrapper">
                    <ul class="list surface">
                        <li class="list-item"><a href="/layanan/standar-pelayanan">Standar Pelayanan</a></li>
                        <li class="list-item"><a href="/layanan/maklumat-pelayanan">Maklumat Pelayanan</a></li>
                        <li class="list-item"><a href="/layanan/prosedur-permohonan-informasi">Prosedur Permohonan Informasi</a></li>
                        <li class="list-item"><a href="/layanan/profil-ppid">Profil PPID</a></li>
                        <li class="list-item"><a href="/layanan/pengajuan-keberatan-informasi-publik">Pengajuan Keberatan Informasi Publik</a></li>
                        <li class="list-item"><a href="/layanan/penyelesaian-sengketa-informasi-publik">Penyelesaian Sengketa Informasi Publik</a></li>
                        <li class="list-item"><a href="/layanan/e-ppid-versi-android">e-PPID versi Android</a></li>
                        <li class="list-item"><a href="/layanan/e-layanan">e-Layanan</a></li>
                    </ul>
                </div>
            </li>
            <li class="item dropdown">
                Kebijakan dan Program
                <div class="dropdown-wrapper">
                    <ul class="list surface">
                        <li class="list-item"><a href="#">Merdeka Belajar</a></li>
                        <li class="list-item dropdown">
                            Program
                            <div class="dropdown-wrapper">
                                <ul class="list surface">
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/program/program-sekolah-penggerak">Program Sekolah Penggerak</a></li>
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/program/assesmen-nasional">Assesmen Nasional</a></li>
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/program/kurikulum-merdeka">Kurikulum Merdeka</a></li>
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/program/gerakan-sekolah-sehat">Gerakan Sekolah Sehat</a></li>
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/program/transisi-paud-sd">Transisi PAUD SD</a></li>
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/program/asesmen-nasional-dan-survei-lingkungan-belajar-sulingjar">Asesmen Nasional & Survei Lingkungan Belajar (Sulingjar)</a></li>
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/program/pemulihan-pembelajaran">Pemulihan Pembelajaran</a></li>
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/program/penerimaan-peserta-didik-baru-ppdb">Penerimaan Peserta Didik Baru (PPDB)</a></li>
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/program/pendidikan-inklusif">Pendidikan Inklusif</a></li>
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/program/dana-alokasi-khusus-dak">Dana Alokasi Khusus (DAK)</a></li>
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/program/bosp">BOSP</a></li>
                                </ul>
                            </div>
                        </li>
                        <li class="list-item dropdown">
                            Platform Teknologi
                            <div class="dropdown-wrapper">
                                <ul class="list surface">
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/platform-teknologi/rkas">RKAS</a></li>
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/platform-teknologi/belajar-id">Belajar.id</a></li>
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/platform-teknologi/siplah">SIPLah</a></li>
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/platform-teknologi/dapodik">DAPODIK</a></li>
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/platform-teknologi/platform-merdeka-mengajar">Platform Merdeka Mengajar</a></li>
                                    <li class="list-item"><a href="/kebijakan-dan-program/merdeka-belajar/platform-teknologi/rapor-pendidikan">Rapor Pendidikan</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="item dropdown">
                Pustaka
                <div class="dropdown-wrapper">
                    <ul class="list surface">
                        <li class="list-item"><a href="/pustaka/panduan">Panduan</a></li>
                        <li class="list-item"><a href="/pustaka/regulasi">Regulasi</a></li>
                        <li class="list-item dropdown">
                            Referensi
                            <div class="dropdown-wrapper">
                                <ul class="list surface">
                                    <li class="list-item"><a href="/pustaka/referensi/buku">Buku</a></li>
                                    <li class="list-item"><a href="/pustaka/referensi/majalah">Majalah</a></li>
                                    <li class="list-item"><a href="/pustaka/referensi/paparan">Paparan</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="item dropdown">
                Praktik Baik
                <div class="dropdown-wrapper">
                    <ul class="list surface">
                        <li class="list-item"><a href="/praktik-baik/guru">Guru</a></li>
                        <li class="list-item"><a href="/praktik-baik/orang-tua">Orang Tua</a></li>
                        <li class="list-item"><a href="/praktik-baik/peserta-didik">Peserta Didik</a></li>
                        <li class="list-item"><a href="/praktik-baik/mitra">Mitra</a></li>
                    </ul>
                </div>
            </li>
            <li class="item dropdown">
                Hubungi Kami
                <div class="dropdown-wrapper">
                    <ul class="list surface">
                        <li class="list-item"><a href="/hubungi-kami/kritik-dan-saran">Kritik dan Saran</a></li>
                        <li class="list-item dropdown">
                            Kontak
                            <div class="dropdown-wrapper">
                                <ul class="list surface">
                                    <li class="list-item"><a href="/hubungi-kami/kontak/ult-kemdikbud">ULT Kemdikbud</a></li>
                                    <li class="list-item"><a href="/hubungi-kami/kontak/satker">Satker</a></li>
                                </ul>
                            </div>
                        </li>
                        <li class="list-item dropdown">
                            Pengaduan
                            <div class="dropdown-wrapper">
                                <ul class="list surface">
                                    <li class="list-item"><a href="/hubungi-kami/pengaduan/kemdikbud-lapor">Kemdikbud-Lapor</a></li>
                                    <li class="list-item"><a href="/hubungi-kami/pengaduan/whistleblowing-system">Whistleblowing System</a></li>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </div>
            </li>
        </ul>
    </nav>
</header>