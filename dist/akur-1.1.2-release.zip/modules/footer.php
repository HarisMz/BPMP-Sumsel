<footer class="container vertical surface-informational-darker text-inverse pt-12 pb-3">
    <nav class="wrapper flex column gap-0">
        <div class="content full text-center">
            <div class="flex grid-mobile grid-1-mobile gap-10 gap-8-mobile">
                <div class="flex column items-start full-mobile width-43 gap-7">
                    <div class="flex column gap-5">
                        <a href="/" class="logo"></a>
                        <div class="flex column">
                            <div class="judul text-balance mb-3">Direktorat Jenderal PAUD, Pendidikan Dasar, dan Pendidikan Menengah</div>
                            <div class="text-balance mb-3">Gedung E Lt. 17-18, Jl. Jend. Sudirman, Senayan, Tanah Abang, Kota Jakarta Pusat, Daerah Khusus Ibukota Jakarta 10270</div>
                            <a href="tel:+6215725610" class="link secondary noline" target="_blank">Telp.: 021-5725610</a>
                            <a href="mailto:pauddikdasmen@kemdikbud.go.id" class="link secondary noline" target="_blank">Email: pauddikdasmen@kemdikbud.go.id</a>
                        </div>
                    </div>
                    <div class="flex column gap-3">
                        <div class="judul">Ikuti Kami</div>
                        <div class="flex gap-5">
                            <a href="https://www.facebook.com/DitjenPAUDDikdasmen/?locale=id_ID" class="media facebook" target="_blank" title="Facebook"></a>
                            <a href="https://www.instagram.com/ditjen.paud.dikdasmen/" class="media instagram" target="_blank" title="Instagram"></a>
                            <a href="https://twitter.com/pauddikdasmen" class="media x" target="_blank" title="X"></a>
                            <a href="https://www.youtube.com/channel/UCE_2hOf7ENLtj09wslgoidw/featured" class="media youtube" target="_blank" title="YouTube"></a>
                            <a href="https://www.tiktok.com/@ditjen.paud.dikdasmen" class="media tiktok" target="_blank" title="TikTok"></a>
                        </div>
                    </div>
                </div>
                <div class="flex column items-start full-mobile width-19 gap-3">
                    <div class="judul">Menu</div>
                    <a href="#" class="link secondary noline" target="_blank">Profil</a>
                    <a href="#" class="link secondary noline" target="_blank">Berita</a>
                    <a href="#" class="link secondary noline" target="_blank">Program Prioritas</a>
                    <a href="#" class="link secondary noline" target="_blank">Platform Teknologi</a>
                    <a href="#" class="link secondary noline" target="_blank">Layanan</a>
                    <a href="#" class="link secondary noline" target="_blank">Pustaka</a>
                    <a href="#" class="link secondary noline" target="_blank">Unit Kerja</a>
                </div>
                <div class="flex column items-start full-mobile width-19 gap-3">
                    <div class="judul">Pranala</div>
                    <a href="#" class="link secondary noline" target="_blank">JDIH</a>
                    <a href="#" class="link secondary noline" target="_blank">ULT Kemendikbud</a>
                    <a href="#" class="link secondary noline" target="_blank">Data Sekolah</a>
                </div>
                <div class="flex column items-start full-mobile width-19 gap-3">
                    <div class="judul">Pengaduan</div>
                    <a href="#" class="link secondary noline" target="_blank">SP4N-LAPOR</a>
                    <a href="#" class="link secondary noline" target="_blank">Wistleblower System</a>
                    <a href="#" class="link secondary noline" target="_blank">Pusat Panggilan (Hubungi 177)</a>
                </div>
            </div>
        </div>
        <div class="flex column content py-4 full justify-center items-start text-inverse">
            <div class="separator-11 vertical full border-color-white"></div>
            <div class="helper pr-12-mobile">© <?= date("Y") ?> • Hak Cipta Kementerian Pendidikan, Kebudayaan, Riset, dan Teknologi • Ditjen PAUD Dikdasmen</div>
        </div>
    </nav>
</footer>