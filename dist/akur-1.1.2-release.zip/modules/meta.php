<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
<meta name="theme-color" content="#000000" id="themeColorMeta">
<link rel="icon" type="image/svg+xml" href="/assets/images/favicon.svg">
<link rel="icon" type="image/png" href="/assets/images/favicon.png" sizes="32x32">
<link rel="icon" type="image/x-icon" href="/assets/images/favicon.ico">
<link rel="shortcut icon" href="/assets/images/favicon.ico">