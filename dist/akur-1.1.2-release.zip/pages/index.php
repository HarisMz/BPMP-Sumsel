<!DOCTYPE html>
<html lang="id">
    <head>
        <meta charset="utf-8">
        <title>
            <!-- Tulis judul halaman, misal: Beranda, Profil, dsb. Judul ini akan ditampilkan pada tab browser. -->
        </title>
        <?php include($_SERVER['DOCUMENT_ROOT'] . '/modules/loadlist.php'); ?>
    </head>
    <body>
        <?php include './modules/header.php'; ?>
        <main>
            <!-- Tempatkan isi dari halaman di dalam bagian ini. -->
        </main>
        <?php include './modules/footer.php'; ?>
    </body>
</html>